// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        //Task_1
        int[] arr1 = {1, 2, 2, 3, 3, 5};
        int[] arr2 = {1, 2, 3, 2, 0};
        System.out.println(isIncreasing(arr1)); // Виведе true
        System.out.println(isIncreasing(arr2)); // Виведе false
    }

    public static boolean isIncreasing(int[] arr) {
        if (arr.length < 2) {
            return true; // Якщо в масиві менше 2 елементів, то вони не можуть бути неспадними
        }

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < arr[i - 1]) {
                return false; // Якщо знайдено елемент, який менший за попередній, то повертаємо false
            }
        }

        return true; // Всі елементи в масиві більше або дорівнюють своєму попередньому
    }

    //Task_2
    public static class FizzBuzz {
        public static void main(String[] args) {
            // Виводимо числа від 1 до 100
            for (int i = 1; i <= 100; i++) {
                // Перевіряємо, чи число кратне 3 і/або 5
                if (i % 3 == 0 && i % 5 == 0) {
                    System.out.println("FizzBuzz");
                } else if (i % 3 == 0) {
                    System.out.println("Fizz");
                } else if (i % 5 == 0) {
                    System.out.println("Buzz");
                } else {
                    System.out.println(i);
                }
            }
        }
    }

    //Task_3
    public static class ArraySplit {
        public static void main(String[] args) {
            int[] arr1 = {1, 1, 1, 2, 1};
            int[] arr2 = {2, 1, 1, 2, 1};
            int[] arr3 = {10, 10};

            System.out.println(canSplitArray(arr1)); // Виведе true
            System.out.println(canSplitArray(arr2)); // Виведе false
            System.out.println(canSplitArray(arr3)); // Виведе true
        }

        public static boolean canSplitArray(int[] nums) {
            int totalSum = 0;
            for (int num : nums) {
                totalSum += num;
            }

            if (totalSum % 2 != 0) {
                return false; // Якщо загальна сума чисел непарна, не можна розділити на дві рівні частини
            }

            int currentSum = 0;
            int i = 0;
            while (i < nums.length) {
                currentSum += nums[i];
                if (currentSum == totalSum / 2) {
                    return true; // Знайдено точку розділення
                }
                i++;
            }

            return false; // Якщо не знайдено точку розділення
        }
    }

}




